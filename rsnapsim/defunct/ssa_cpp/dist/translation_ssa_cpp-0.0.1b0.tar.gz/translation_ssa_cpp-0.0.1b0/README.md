mRNA Translation SSA for rSNAPsim
-----------------
This contains the c++ cython package of the mRNA translation model described in Aguilera 2019

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6816579/

-----------------
