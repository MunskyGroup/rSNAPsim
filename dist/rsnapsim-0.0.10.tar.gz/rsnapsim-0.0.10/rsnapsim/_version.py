# -*- coding: utf-8 -*-
"""
Created on Mon Dec 21 15:33:35 2020

@author: willi
"""

__version__ = "0.0.10"